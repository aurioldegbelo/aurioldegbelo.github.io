This folder contains examples illustrating the use of the GeoInsight Ontology Design Pattern. 

- demoexamples.ttl shows example triples for the annotation in Turtle
- demoqueries.rq shows example SPARQL queries executed on the demoexamples.ttl file
- the .owl file is the current version of the ontology
- the viz folder contains screenshots of the examples used (in case the links used are no longer accessible)